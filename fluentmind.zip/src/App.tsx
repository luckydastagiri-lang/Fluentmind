import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './AuthContext';
import Layout from './components/Layout';
import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import Practice from './pages/Practice';
import Conversation from './pages/Conversation';
import Quiz from './pages/Quiz';
import Games from './pages/Games';
import Dictionary from './pages/Dictionary';

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>;
  if (!user) return <Navigate to="/" />;
  return <>{children}</>;
};

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="practice" element={<Practice />} />
            <Route path="conversation" element={<Conversation />} />
            <Route path="quiz" element={<Quiz />} />
            <Route path="games" element={<Games />} />
            <Route path="dictionary" element={<Dictionary />} />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}
