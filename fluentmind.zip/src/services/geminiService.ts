import { GoogleGenAI, Type } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface FluencyAnalysis {
  correctedText: string;
  grammarScore: number;
  vocabularyScore: number;
  clarityScore: number;
  fluencyScore: number;
  feedback: string[];
  recommendations: string[];
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface GameChallenge {
  sentence: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
}

export interface DictionaryDefinition {
  definition: string;
  example?: string;
  synonyms?: string[];
  antonyms?: string[];
}

export interface DictionaryMeaning {
  partOfSpeech: string;
  definitions: DictionaryDefinition[];
}

export interface DictionaryEntry {
  word: string;
  phonetic?: string;
  origin?: string;
  meanings: DictionaryMeaning[];
  usageNotes?: string;
}

export const lookupWord = async (word: string): Promise<DictionaryEntry> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: `Act as an advanced English dictionary (like the Oxford Advanced Learner's Dictionary). Provide a comprehensive, advanced-level entry for the word "${word}". Include phonetic transcription, origin/etymology, and for each part of speech, provide advanced definitions, example sentences, synonyms, and antonyms. Also include any advanced usage notes if applicable.`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            word: { type: Type.STRING },
            phonetic: { type: Type.STRING, description: "IPA phonetic transcription" },
            origin: { type: Type.STRING, description: "Etymology or origin of the word" },
            meanings: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  partOfSpeech: { type: Type.STRING, description: "e.g., noun, verb, adjective" },
                  definitions: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        definition: { type: Type.STRING },
                        example: { type: Type.STRING },
                        synonyms: { type: Type.ARRAY, items: { type: Type.STRING } },
                        antonyms: { type: Type.ARRAY, items: { type: Type.STRING } }
                      },
                      required: ["definition"]
                    }
                  }
                },
                required: ["partOfSpeech", "definitions"]
              }
            },
            usageNotes: { type: Type.STRING, description: "Advanced usage notes, common collocations, or nuances" }
          },
          required: ["word", "meanings"]
        }
      }
    });

    if (!response.text) {
      throw new Error("No response from AI");
    }

    return JSON.parse(response.text) as DictionaryEntry;
  } catch (error) {
    console.error("Error looking up word:", error);
    throw error;
  }
};

export const generateGameLevel = async (level: number, topic: string, difficulty: string): Promise<GameChallenge[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: `Generate a 5-question grammar game for Level ${level} (${difficulty} difficulty) focusing on "${topic}". 
      Each question should be a "fill in the blank" sentence where the blank is represented by "___".
      Provide 4 options for the blank, the exact correct answer string, and a brief explanation.`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              sentence: { type: Type.STRING, description: "The sentence with a '___' for the blank." },
              options: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "Exactly 4 possible words/phrases to fill the blank."
              },
              correctAnswer: { type: Type.STRING, description: "The exact string from options that is correct." },
              explanation: { type: Type.STRING, description: "Brief explanation of the grammar rule." }
            },
            required: ["sentence", "options", "correctAnswer", "explanation"]
          }
        }
      }
    });

    if (!response.text) {
      throw new Error("No response from AI");
    }

    return JSON.parse(response.text) as GameChallenge[];
  } catch (error) {
    console.error("Error generating game level:", error);
    throw error;
  }
};

export const generateQuiz = async (topic: string, difficulty: string = 'Medium'): Promise<QuizQuestion[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: `Generate a 5-question multiple choice English learning quiz about "${topic}". The difficulty level should be ${difficulty}. Make the questions engaging and educational.`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING, description: "The quiz question." },
              options: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "Exactly 4 possible answers."
              },
              correctAnswerIndex: { type: Type.INTEGER, description: "0-based index of the correct option (0 to 3)." },
              explanation: { type: Type.STRING, description: "Brief explanation of why the answer is correct." }
            },
            required: ["question", "options", "correctAnswerIndex", "explanation"]
          }
        }
      }
    });

    if (!response.text) {
      throw new Error("No response from AI");
    }

    return JSON.parse(response.text) as QuizQuestion[];
  } catch (error) {
    console.error("Error generating quiz:", error);
    throw error;
  }
};

export const analyzeText = async (text: string): Promise<FluencyAnalysis> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: `Analyze the following text for English grammar, vocabulary, clarity, and overall fluency.
      
      Text to analyze: "${text}"
      
      Provide a corrected version of the text.
      Score the grammar, vocabulary, and clarity from 0 to 100.
      Calculate an overall fluency score using this formula: (0.4 * grammar) + (0.3 * vocabulary) + (0.3 * clarity).
      Provide 2-3 specific feedback points on mistakes or improvements.
      Provide 1-2 personalized learning recommendations (e.g., "Practice past tense").`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            correctedText: { type: Type.STRING, description: "The grammatically corrected and improved text." },
            grammarScore: { type: Type.NUMBER, description: "Score out of 100 for grammar." },
            vocabularyScore: { type: Type.NUMBER, description: "Score out of 100 for vocabulary diversity and usage." },
            clarityScore: { type: Type.NUMBER, description: "Score out of 100 for sentence readability and clarity." },
            fluencyScore: { type: Type.NUMBER, description: "Overall fluency score calculated using the formula." },
            feedback: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Specific feedback points."
            },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Learning recommendations."
            }
          },
          required: ["correctedText", "grammarScore", "vocabularyScore", "clarityScore", "fluencyScore", "feedback", "recommendations"]
        }
      }
    });

    if (!response.text) {
      throw new Error("No response from AI");
    }

    return JSON.parse(response.text) as FluencyAnalysis;
  } catch (error) {
    console.error("Error analyzing text:", error);
    throw error;
  }
};

export const createConversationChat = (scenario: string) => {
  let systemInstruction = "You are an AI conversation partner helping a user practice English.";
  
  if (scenario === 'Job Interview') {
    systemInstruction = "You are a hiring manager conducting a job interview. Ask typical interview questions one by one. Keep your responses concise and professional. Wait for the user to answer before asking the next question.";
  } else if (scenario === 'Casual Conversation') {
    systemInstruction = "You are a friendly person having a casual chat at a coffee shop. Keep the conversation light, ask about hobbies, weekend plans, etc. Keep responses short and natural.";
  } else if (scenario === 'Presentation Practice') {
    systemInstruction = "You are an audience member listening to a presentation. Ask clarifying questions or provide brief reactions to what the user is presenting.";
  }

  return ai.chats.create({
    model: 'gemini-3.1-pro-preview',
    config: {
      systemInstruction,
    }
  });
};
