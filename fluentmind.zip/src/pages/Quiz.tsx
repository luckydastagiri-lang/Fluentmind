import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, BookOpen, Briefcase, MessageCircle, Loader2, CheckCircle2, XCircle, Trophy, ArrowRight, RotateCcw } from 'lucide-react';
import { generateQuiz, QuizQuestion } from '../services/geminiService';
import { db } from '../firebase';
import { doc, updateDoc, increment } from 'firebase/firestore';
import { useAuth } from '../AuthContext';

const TOPICS = [
  { id: 'grammar', title: 'Advanced Grammar', icon: BookOpen, color: 'bg-blue-50 text-blue-600', border: 'border-blue-200' },
  { id: 'vocabulary', title: 'Vocabulary Builder', icon: Brain, color: 'bg-purple-50 text-purple-600', border: 'border-purple-200' },
  { id: 'business', title: 'Business English', icon: Briefcase, color: 'bg-emerald-50 text-emerald-600', border: 'border-emerald-200' },
  { id: 'idioms', title: 'Idioms & Phrases', icon: MessageCircle, color: 'bg-amber-50 text-amber-600', border: 'border-amber-200' },
];

export default function Quiz() {
  const { user } = useAuth();
  const [activeTopic, setActiveTopic] = useState<string | null>(null);
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');
  const [isLoading, setIsLoading] = useState(false);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const startQuiz = async (topicTitle: string) => {
    setActiveTopic(topicTitle);
    setIsLoading(true);
    try {
      const generatedQuestions = await generateQuiz(topicTitle, difficulty);
      setQuestions(generatedQuestions);
      setCurrentIndex(0);
      setScore(0);
      setIsFinished(false);
      setIsAnswered(false);
      setSelectedOption(null);
    } catch (error: any) {
      console.error("Failed to load quiz", error);
      if (error?.message?.includes('429') || error?.message?.includes('RESOURCE_EXHAUSTED') || error?.message?.includes('quota')) {
        alert("The quiz service is currently experiencing high traffic (rate limit exceeded). Please try again in a moment.");
      } else {
        alert("Failed to generate quiz. Please try again.");
      }
      setActiveTopic(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOptionSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);
    
    if (index === questions[currentIndex].correctAnswerIndex) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = async () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setIsFinished(true);
      if (user) {
        // Award 10 points per correct answer
        const pointsEarned = score * 10;
        if (pointsEarned > 0) {
          const userRef = doc(db, 'users', user.uid);
          await updateDoc(userRef, {
            totalScore: increment(pointsEarned)
          });
        }
      }
    }
  };

  const resetQuiz = () => {
    setActiveTopic(null);
    setQuestions([]);
    setCurrentIndex(0);
    setScore(0);
    setIsFinished(false);
    setIsAnswered(false);
    setSelectedOption(null);
  };

  if (isLoading) {
    return (
      <div className="h-[calc(100vh-8rem)] flex flex-col items-center justify-center space-y-6">
        <div className="w-20 h-20 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-center shadow-sm">
          <Loader2 className="w-8 h-8 text-slate-900 animate-spin" />
        </div>
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Generating your quiz...</h2>
          <p className="text-slate-500 text-sm">Our AI is crafting personalized questions for you.</p>
        </div>
      </div>
    );
  }

  if (isFinished) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl mx-auto mt-12 bg-white p-10 rounded-3xl shadow-sm border border-slate-200/60 text-center"
      >
        <div className="w-24 h-24 bg-yellow-50 border border-yellow-100 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-sm">
          <Trophy className="w-10 h-10 text-yellow-600" />
        </div>
        <h2 className="text-3xl font-bold text-slate-900 mb-3 tracking-tight">Quiz Complete!</h2>
        <p className="text-sm text-slate-500 mb-8">You scored <span className="font-semibold text-slate-900">{score}</span> out of {questions.length}</p>
        
        <div className="w-full bg-slate-100 rounded-full h-2 mb-10 overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${percentage}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className={`h-full rounded-full ${percentage >= 80 ? 'bg-emerald-500' : percentage >= 50 ? 'bg-amber-500' : 'bg-red-500'}`}
          />
        </div>

        <div className="flex justify-center gap-4">
          <button 
            onClick={resetQuiz}
            className="flex items-center gap-2 px-8 py-3.5 bg-slate-900 text-white rounded-full font-semibold text-sm hover:bg-slate-800 hover:-translate-y-0.5 shadow-md transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            Try Another Quiz
          </button>
        </div>
      </motion.div>
    );
  }

  if (questions.length > 0) {
    const currentQ = questions[currentIndex];
    return (
      <div className="max-w-3xl mx-auto space-y-8">
        <header className="flex justify-between items-center bg-white p-4 rounded-2xl border border-slate-200/60 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                Question {currentIndex + 1} of {questions.length}
              </span>
            </div>
            <div className="h-6 w-px bg-slate-200"></div>
            <h1 className="text-sm font-semibold text-slate-900 tracking-tight">{activeTopic}</h1>
          </div>
          <div className="flex items-center gap-2 text-slate-900 font-bold text-sm bg-slate-50 px-3 py-1.5 rounded-md border border-slate-100">
            Score: {score}
          </div>
        </header>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 rounded-full h-1.5">
          <div 
            className="bg-slate-900 h-1.5 rounded-full transition-all duration-300"
            style={{ width: `${((currentIndex) / questions.length) * 100}%` }}
          />
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.3 }}
            className="bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-slate-200/60"
          >
            <h2 className="text-xl md:text-2xl font-medium text-slate-900 mb-10 leading-relaxed tracking-tight">
              {currentQ.question}
            </h2>

            <div className="space-y-3">
              {currentQ.options.map((option, idx) => {
                let buttonClass = "w-full text-left p-5 rounded-2xl border transition-all text-sm font-medium ";
                
                if (!isAnswered) {
                  buttonClass += "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50 text-slate-700 hover:text-slate-900 shadow-sm";
                } else {
                  if (idx === currentQ.correctAnswerIndex) {
                    buttonClass += "border-emerald-500 bg-emerald-50 text-emerald-800 shadow-sm";
                  } else if (idx === selectedOption) {
                    buttonClass += "border-red-500 bg-red-50 text-red-800 shadow-sm";
                  } else {
                    buttonClass += "border-slate-100 bg-slate-50 text-slate-400 opacity-50";
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={isAnswered}
                    onClick={() => handleOptionSelect(idx)}
                    className={buttonClass}
                  >
                    <div className="flex justify-between items-center">
                      <span>{option}</span>
                      {isAnswered && idx === currentQ.correctAnswerIndex && <CheckCircle2 className="w-5 h-5 text-emerald-500" />}
                      {isAnswered && idx === selectedOption && idx !== currentQ.correctAnswerIndex && <XCircle className="w-5 h-5 text-red-500" />}
                    </div>
                  </button>
                );
              })}
            </div>

            {isAnswered && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-8 p-6 bg-slate-50 rounded-2xl border border-slate-200/60 shadow-sm"
              >
                <h4 className="font-semibold text-slate-900 mb-2 text-sm uppercase tracking-wider">Explanation</h4>
                <p className="text-slate-700 leading-relaxed text-sm">{currentQ.explanation}</p>
                
                <button
                  onClick={handleNext}
                  className="mt-6 w-full flex items-center justify-center gap-2 py-3.5 bg-slate-900 text-white rounded-full font-semibold text-sm hover:bg-slate-800 hover:-translate-y-0.5 shadow-md transition-all"
                >
                  {currentIndex < questions.length - 1 ? 'Next Question' : 'See Results'}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-10">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">AI Quizzes</h1>
          <p className="text-slate-500 mt-2 text-sm">Test your knowledge with dynamically generated quizzes.</p>
        </div>
        
        <div className="bg-white p-1.5 rounded-full border border-slate-200/60 shadow-sm inline-flex">
          {['Easy', 'Medium', 'Hard'].map((level) => (
            <button
              key={level}
              onClick={() => setDifficulty(level as any)}
              className={`px-5 py-2 rounded-full font-semibold text-xs transition-all uppercase tracking-wider ${
                difficulty === level
                  ? 'bg-slate-900 text-white shadow-md shadow-slate-900/10'
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              {level}
            </button>
          ))}
        </div>
      </header>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ staggerChildren: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-2 gap-6"
      >
        {TOPICS.map((topic, idx) => (
          <motion.button
            key={topic.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: idx * 0.1 }}
            whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)" }}
            whileTap={{ scale: 0.98 }}
            onClick={() => startQuiz(topic.title)}
            className={`group relative overflow-hidden bg-white p-8 rounded-3xl border border-slate-200/60 shadow-sm transition-all text-left flex flex-col items-start`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 border shadow-sm ${topic.color}`}>
              <topic.icon className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2 tracking-tight group-hover:text-slate-700 transition-colors">{topic.title}</h3>
            <p className="text-slate-500 text-sm leading-relaxed">Generate a 5-question <span className="font-semibold text-slate-700">{difficulty.toLowerCase()}</span> quiz to test your skills in {topic.title.toLowerCase()}.</p>
            
            <div className="mt-8 flex items-center gap-2 text-slate-900 font-semibold text-sm opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all">
              Start Quiz <ArrowRight className="w-4 h-4" />
            </div>
          </motion.button>
        ))}
      </motion.div>
    </div>
  );
}
