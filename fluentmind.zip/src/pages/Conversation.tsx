import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, User, Bot, Loader2, PlayCircle } from 'lucide-react';
import { createConversationChat } from '../services/geminiService';
import { db } from '../firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../AuthContext';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
}

export default function Conversation() {
  const { user } = useAuth();
  const [scenario, setScenario] = useState<string>('Job Interview');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatSession, setChatSession] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scenarios = ['Job Interview', 'Casual Conversation', 'Presentation Practice'];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const startConversation = () => {
    const session = createConversationChat(scenario);
    setChatSession(session);
    setMessages([{
      id: Date.now().toString(),
      text: `Hello! Let's start our ${scenario.toLowerCase()}. I'm ready when you are.`,
      sender: 'ai'
    }]);
  };

  const handleSend = async () => {
    if (!input.trim() || !chatSession || !user) return;

    const userMessage: Message = { id: Date.now().toString(), text: input, sender: 'user' };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await chatSession.sendMessage({ message: userMessage.text });
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response.text,
        sender: 'ai'
      };
      setMessages(prev => [...prev, aiMessage]);

      // Save to Firestore (simplified session logging)
      const sessionRef = collection(db, 'users', user.uid, 'sessions');
      await addDoc(sessionRef, {
        userId: user.uid,
        type: 'conversation',
        inputText: userMessage.text,
        correctedText: response.text, // Not strictly corrected, but AI response
        grammarScore: 85, // Placeholder for conversation mode
        vocabularyScore: 85,
        clarityScore: 85,
        fluencyScore: 85,
        feedback: ['Conversation practice logged.'],
        recommendations: ['Keep practicing!'],
        createdAt: serverTimestamp()
      });

    } catch (error: any) {
      console.error('Failed to send message', error);
      if (error?.message?.includes('429') || error?.message?.includes('RESOURCE_EXHAUSTED') || error?.message?.includes('quota')) {
        setMessages(prev => [...prev, { id: Date.now().toString(), text: "I'm currently experiencing high traffic (rate limit exceeded). Please try again in a moment.", sender: 'ai' }]);
      } else {
        setMessages(prev => [...prev, { id: Date.now().toString(), text: "Sorry, I encountered an error. Let's try again.", sender: 'ai' }]);
      }
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-8rem)] flex flex-col">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">AI Conversation</h1>
        <p className="text-slate-500 mt-2 text-sm">Practice real-world scenarios with an AI partner.</p>
      </header>

      {!chatSession ? (
        <div className="flex-1 flex flex-col items-center justify-center bg-white rounded-2xl border border-slate-200/60 shadow-sm p-8 md:p-12 text-center">
          <div className="w-20 h-20 bg-slate-50 text-slate-900 rounded-2xl flex items-center justify-center mb-8 border border-slate-100 shadow-sm">
            <PlayCircle className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-6 tracking-tight">Choose a Scenario</h2>
          <div className="flex flex-wrap justify-center gap-3 mb-10">
            {scenarios.map(s => (
              <button
                key={s}
                onClick={() => setScenario(s)}
                className={`px-5 py-2.5 rounded-full font-medium text-sm transition-all ${
                  scenario === s 
                    ? 'bg-slate-900 text-white shadow-md shadow-slate-900/10' 
                    : 'bg-white border border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900 shadow-sm'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
          <button
            onClick={startConversation}
            className="px-8 py-3.5 bg-slate-900 text-white rounded-full font-semibold text-sm shadow-md hover:bg-slate-800 hover:-translate-y-0.5 transition-all"
          >
            Start Practice
          </button>
        </div>
      ) : (
        <div className="flex-1 flex flex-col bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
          {/* Chat Header */}
          <div className="p-4 border-b border-slate-100 bg-white flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-slate-50 border border-slate-100 text-slate-900 rounded-full flex items-center justify-center">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 text-sm">{scenario} Partner</h3>
                <p className="text-[10px] uppercase tracking-wider font-semibold text-emerald-500 mt-0.5">AI is online</p>
              </div>
            </div>
            <button
              onClick={() => setChatSession(null)}
              className="text-xs font-semibold text-slate-400 hover:text-red-500 uppercase tracking-wider transition-colors px-3 py-1.5 rounded-md hover:bg-red-50"
            >
              End Session
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/30">
            <AnimatePresence initial={false}>
              {messages.map((msg) => (
                <motion.div 
                  key={msg.id} 
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ duration: 0.3 }}
                  className={`flex gap-4 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-sm ${
                    msg.sender === 'user' ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600'
                  }`}>
                    {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                  </div>
                  <div className={`max-w-[75%] p-4 rounded-2xl text-sm shadow-sm ${
                    msg.sender === 'user' 
                      ? 'bg-slate-900 text-white rounded-tr-sm' 
                      : 'bg-white border border-slate-200/60 text-slate-800 rounded-tl-sm'
                  }`}>
                    <p className="leading-relaxed">{msg.text}</p>
                  </div>
                </motion.div>
              ))}
              {isTyping && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="flex gap-4"
                >
                  <div className="w-8 h-8 rounded-full bg-white border border-slate-200 text-slate-600 flex items-center justify-center shrink-0 shadow-sm">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div className="bg-white border border-slate-200/60 p-4 rounded-2xl rounded-tl-sm shadow-sm flex items-center gap-2">
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                    >
                      <Loader2 className="w-4 h-4 text-slate-400" />
                    </motion.div>
                    <span className="text-slate-400 text-xs font-medium uppercase tracking-wider">Typing...</span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-slate-100 bg-white">
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type your response..."
                className="flex-1 bg-slate-50 border border-slate-200/60 rounded-full px-6 py-3.5 text-sm focus:outline-none focus:ring-4 focus:ring-slate-100 focus:border-slate-400 transition-all"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isTyping}
                className="w-12 h-12 bg-slate-900 text-white rounded-full flex items-center justify-center hover:bg-slate-800 hover:-translate-y-0.5 shadow-md disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0 transition-all shrink-0"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
