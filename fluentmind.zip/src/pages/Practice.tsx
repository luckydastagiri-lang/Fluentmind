import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { Mic, MicOff, Send, Loader2, CheckCircle2, AlertCircle, Lightbulb } from 'lucide-react';
import { analyzeText, FluencyAnalysis } from '../services/geminiService';
import { db } from '../firebase';
import { collection, addDoc, serverTimestamp, doc, updateDoc, increment } from 'firebase/firestore';
import { useAuth } from '../AuthContext';

export default function Practice() {
  const { user } = useAuth();
  const [text, setText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<FluencyAnalysis | null>(null);
  const recognitionRef = useRef<any>(null);

  const startRecording = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    recognitionRef.current = new SpeechRecognition();
    recognitionRef.current.continuous = true;
    recognitionRef.current.interimResults = true;

    recognitionRef.current.onresult = (event: any) => {
      let finalTranscript = '';
      let interimTranscript = '';
      
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }
      
      if (finalTranscript) {
        setText(prev => prev + (prev ? ' ' : '') + finalTranscript.trim());
      }
    };

    recognitionRef.current.onerror = (event: any) => {
      console.error('Speech recognition error', event.error);
      setIsRecording(false);
    };

    recognitionRef.current.onend = () => {
      setIsRecording(false);
    };

    recognitionRef.current.start();
    setIsRecording(true);
  };

  const stopRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleAnalyze = async () => {
    if (!text.trim() || !user) return;

    setIsAnalyzing(true);
    setResult(null);

    try {
      const analysis = await analyzeText(text);
      setResult(analysis);

      // Save to Firestore
      const sessionRef = collection(db, 'users', user.uid, 'sessions');
      await addDoc(sessionRef, {
        userId: user.uid,
        type: 'text',
        inputText: text,
        correctedText: analysis.correctedText,
        grammarScore: analysis.grammarScore,
        vocabularyScore: analysis.vocabularyScore,
        clarityScore: analysis.clarityScore,
        fluencyScore: analysis.fluencyScore,
        feedback: analysis.feedback,
        recommendations: analysis.recommendations,
        createdAt: serverTimestamp()
      });

      // Update user stats
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        totalScore: increment(analysis.fluencyScore),
        streak: increment(1) // Simplified streak logic
      });

    } catch (error: any) {
      console.error('Analysis failed', error);
      if (error?.message?.includes('429') || error?.message?.includes('RESOURCE_EXHAUSTED') || error?.message?.includes('quota')) {
        alert('The analysis service is currently experiencing high traffic (rate limit exceeded). Please try again in a moment.');
      } else {
        alert('Failed to analyze text. Please try again.');
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header className="mb-10">
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Practice Area</h1>
        <p className="text-slate-500 mt-2 text-sm">Type or speak to get instant AI feedback on your English.</p>
      </header>

      <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-200/60 shadow-sm">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Start typing or speaking here..."
          className="w-full h-48 p-5 bg-slate-50 border border-slate-200/60 rounded-xl focus:ring-4 focus:ring-slate-100 focus:border-slate-400 resize-none transition-all text-slate-900 placeholder:text-slate-400 text-base"
        />
        
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <button
            onClick={isRecording ? stopRecording : startRecording}
            className={`flex items-center justify-center gap-2 px-5 py-2.5 rounded-full font-medium transition-all w-full sm:w-auto ${
              isRecording 
                ? 'bg-red-50 text-red-600 hover:bg-red-100 ring-2 ring-red-100' 
                : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300 hover:bg-slate-50 shadow-sm'
            }`}
          >
            {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            <span className="text-sm">{isRecording ? 'Stop Recording' : 'Use Voice'}</span>
          </button>

          <button
            onClick={handleAnalyze}
            disabled={!text.trim() || isAnalyzing}
            className="flex items-center justify-center gap-2 px-8 py-2.5 bg-slate-900 text-white rounded-full font-medium hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all w-full sm:w-auto shadow-sm"
          >
            {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            <span className="text-sm">{isAnalyzing ? 'Analyzing...' : 'Analyze Text'}</span>
          </button>
        </div>
      </div>

      {result && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ staggerChildren: 0.1 }}
          className="space-y-6"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Fluency', score: result.fluencyScore, color: 'text-slate-900', bg: 'bg-slate-50/50', border: 'border-slate-200/60' },
              { label: 'Grammar', score: result.grammarScore, color: 'text-emerald-600', bg: 'bg-emerald-50/50', border: 'border-emerald-100' },
              { label: 'Vocabulary', score: result.vocabularyScore, color: 'text-amber-600', bg: 'bg-amber-50/50', border: 'border-amber-100' },
              { label: 'Clarity', score: result.clarityScore, color: 'text-blue-600', bg: 'bg-blue-50/50', border: 'border-blue-100' },
            ].map((stat, idx) => (
              <motion.div 
                key={idx} 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: idx * 0.1 }}
                whileHover={{ y: -4, boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)" }}
                className={`bg-white p-5 rounded-2xl border ${stat.border} text-center shadow-sm transition-colors`}
              >
                <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">{stat.label}</p>
                <p className={`text-3xl font-bold tracking-tight ${stat.color}`}>{stat.score}</p>
              </motion.div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="bg-white p-6 md:p-8 rounded-2xl border border-slate-200/60 shadow-sm space-y-8"
          >
            <div>
              <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2 mb-4">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                Corrected Version
              </h3>
              <p className="p-5 bg-emerald-50/50 border border-emerald-100/50 text-emerald-900 rounded-xl leading-relaxed text-base">
                {result.correctedText}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2 mb-4">
                  <AlertCircle className="w-5 h-5 text-amber-500" />
                  Feedback
                </h3>
                <ul className="space-y-3">
                  {result.feedback.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-slate-700 bg-amber-50/50 border border-amber-100/50 p-4 rounded-xl text-sm leading-relaxed">
                      <span className="text-amber-500 mt-0.5 shrink-0">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2 mb-4">
                  <Lightbulb className="w-5 h-5 text-blue-500" />
                  Recommendations
                </h3>
                <ul className="space-y-3">
                  {result.recommendations.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-slate-700 bg-blue-50/50 border border-blue-100/50 p-4 rounded-xl text-sm leading-relaxed">
                      <span className="text-blue-500 mt-0.5 shrink-0">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
