import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { MessageSquare, Sparkles, TrendingUp, Mic } from 'lucide-react';
import { useAuth } from '../AuthContext';
import { loginWithGoogle } from '../firebase';

export default function Landing() {
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  const handleLogin = async () => {
    try {
      await loginWithGoogle();
      navigate('/dashboard');
    } catch (error) {
      console.error('Login failed', error);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <header className="px-8 py-6 flex justify-between items-center bg-white border-b border-slate-200/60">
        <div className="flex items-center gap-2 text-slate-900 font-bold text-xl tracking-tight">
          <div className="w-8 h-8 bg-slate-900 text-white rounded-lg flex items-center justify-center">
            <MessageSquare className="w-4 h-4" />
          </div>
          FluentMind
        </div>
        <button
          onClick={handleLogin}
          className="px-6 py-2.5 bg-slate-900 text-white rounded-full font-semibold text-sm hover:bg-slate-800 hover:-translate-y-0.5 shadow-md transition-all"
        >
          Sign In
        </button>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="max-w-3xl"
        >
          <motion.h1 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-5xl md:text-6xl font-extrabold text-slate-900 tracking-tight mb-6 leading-tight"
          >
            Master English with your <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-600 to-slate-900">AI Coach</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg text-slate-500 mb-10 leading-relaxed max-w-2xl mx-auto"
          >
            Improve your grammar, vocabulary, and fluency through real-time feedback, voice practice, and personalized AI conversations.
          </motion.p>
          <motion.button
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleLogin}
            className="px-8 py-4 bg-slate-900 text-white rounded-full font-semibold text-sm shadow-lg hover:shadow-xl hover:bg-slate-800 transition-colors"
          >
            Start Practicing Now
          </motion.button>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl w-full"
        >
          {[
            {
              icon: Sparkles,
              title: 'Smart Corrections',
              desc: 'Get instant feedback on grammar, clarity, and vocabulary with actionable suggestions.',
            },
            {
              icon: TrendingUp,
              title: 'Progress Analytics',
              desc: 'Track your fluency score over time with detailed charts and personalized insights.',
            },
            {
              icon: Mic,
              title: 'Voice & Conversation',
              desc: 'Practice real-world scenarios like job interviews or casual chats with voice support.',
            },
          ].map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)" }}
              className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200/60 flex flex-col items-start text-left transition-colors"
            >
              <div className="w-12 h-12 bg-slate-50 border border-slate-100 text-slate-900 rounded-2xl flex items-center justify-center mb-6 shadow-sm">
                <feature.icon className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2 tracking-tight">{feature.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </main>
    </div>
  );
}
