import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Gamepad2, Heart, Star, Trophy, ArrowRight, Loader2, RotateCcw, ShieldAlert, Zap } from 'lucide-react';
import { generateGameLevel, GameChallenge } from '../services/geminiService';
import { db } from '../firebase';
import { doc, updateDoc, increment, getDoc, setDoc } from 'firebase/firestore';
import { useAuth } from '../AuthContext';

const LEVELS = [
  { id: 1, title: 'Present & Past', difficulty: 'Basic', topic: 'Basic Present and Past Tenses', color: 'bg-emerald-100 text-emerald-700', border: 'border-emerald-200' },
  { id: 2, title: 'Articles & Prepositions', difficulty: 'Basic', topic: 'A, An, The, and Basic Prepositions (in, on, at)', color: 'bg-emerald-100 text-emerald-700', border: 'border-emerald-200' },
  { id: 3, title: 'Pronouns & Possessives', difficulty: 'Basic', topic: 'Subject, Object Pronouns, and Possessive Adjectives', color: 'bg-emerald-100 text-emerald-700', border: 'border-emerald-200' },
  { id: 4, title: 'Perfect Tenses', difficulty: 'Intermediate', topic: 'Present Perfect and Past Perfect Tenses', color: 'bg-amber-100 text-amber-700', border: 'border-amber-200' },
  { id: 5, title: 'Modals', difficulty: 'Intermediate', topic: 'Modal Verbs (can, could, should, must, might)', color: 'bg-amber-100 text-amber-700', border: 'border-amber-200' },
  { id: 6, title: 'Conditionals (0 & 1)', difficulty: 'Intermediate', topic: 'Zero and First Conditionals', color: 'bg-amber-100 text-amber-700', border: 'border-amber-200' },
  { id: 7, title: 'Passive Voice', difficulty: 'Advanced', topic: 'Passive Voice across different tenses', color: 'bg-rose-100 text-rose-700', border: 'border-rose-200' },
  { id: 8, title: 'Advanced Conditionals', difficulty: 'Advanced', topic: 'Second, Third, and Mixed Conditionals', color: 'bg-rose-100 text-rose-700', border: 'border-rose-200' },
  { id: 9, title: 'Relative Clauses', difficulty: 'Advanced', topic: 'Defining and Non-defining Relative Clauses', color: 'bg-rose-100 text-rose-700', border: 'border-rose-200' },
];

export default function Games() {
  const { user } = useAuth();
  const [gameState, setGameState] = useState<'menu' | 'loading' | 'playing' | 'gameover' | 'victory'>('menu');
  const [currentLevel, setCurrentLevel] = useState<typeof LEVELS[0] | null>(null);
  const [challenges, setChallenges] = useState<GameChallenge[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [lives, setLives] = useState(3);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [unlockedLevel, setUnlockedLevel] = useState(1);

  useEffect(() => {
    const fetchProgress = async () => {
      if (user) {
        const docRef = doc(db, 'users', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists() && docSnap.data().highestGameLevel) {
          setUnlockedLevel(docSnap.data().highestGameLevel);
        } else {
          await updateDoc(docRef, { highestGameLevel: 1 });
        }
      }
    };
    fetchProgress();
  }, [user]);

  const startGame = async (level: typeof LEVELS[0]) => {
    if (level.id > unlockedLevel) return; // Locked
    
    setCurrentLevel(level);
    setGameState('loading');
    
    try {
      const generatedChallenges = await generateGameLevel(level.id, level.topic, level.difficulty);
      setChallenges(generatedChallenges);
      setCurrentIndex(0);
      setLives(3);
      setScore(0);
      setIsAnswered(false);
      setSelectedAnswer(null);
      setGameState('playing');
    } catch (error: any) {
      console.error("Failed to load game", error);
      if (error?.message?.includes('429') || error?.message?.includes('RESOURCE_EXHAUSTED') || error?.message?.includes('quota')) {
        alert("The game service is currently experiencing high traffic (rate limit exceeded). Please try again in a moment.");
      } else {
        alert("Failed to generate game level. Please try again.");
      }
      setGameState('menu');
    }
  };

  const handleAnswer = (answer: string) => {
    if (isAnswered) return;
    
    setSelectedAnswer(answer);
    setIsAnswered(true);
    
    const isCorrect = answer === challenges[currentIndex].correctAnswer;
    
    if (isCorrect) {
      setScore(prev => prev + 100);
    } else {
      setLives(prev => prev - 1);
    }
  };

  const handleNext = async () => {
    if (lives <= 0) {
      setGameState('gameover');
      return;
    }

    if (currentIndex < challenges.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setIsAnswered(false);
      setSelectedAnswer(null);
    } else {
      // Victory!
      setGameState('victory');
      if (user && currentLevel) {
        const userRef = doc(db, 'users', user.uid);
        const newUnlocked = Math.max(unlockedLevel, currentLevel.id + 1);
        await updateDoc(userRef, {
          totalScore: increment(score + (lives * 50)), // Bonus for remaining lives
          highestGameLevel: newUnlocked
        });
        setUnlockedLevel(newUnlocked);
      }
    }
  };

  const returnToMenu = () => {
    setGameState('menu');
    setCurrentLevel(null);
    setChallenges([]);
  };

  if (gameState === 'loading') {
    return (
      <div className="h-[calc(100vh-8rem)] flex flex-col items-center justify-center space-y-6">
        <div className="w-20 h-20 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-center shadow-sm">
          <Loader2 className="w-8 h-8 text-slate-900 animate-spin" />
        </div>
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Generating Level {currentLevel?.id}...</h2>
          <p className="text-slate-500 text-sm">Preparing grammar challenges: {currentLevel?.topic}</p>
        </div>
      </div>
    );
  }

  if (gameState === 'gameover' || gameState === 'victory') {
    const isVictory = gameState === 'victory';
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md mx-auto mt-12 bg-white p-10 rounded-3xl shadow-sm border border-slate-200/60 text-center"
      >
        <div className={`w-24 h-24 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-sm border ${isVictory ? 'bg-emerald-50 border-emerald-100' : 'bg-red-50 border-red-100'}`}>
          {isVictory ? <Trophy className="w-10 h-10 text-emerald-600" /> : <ShieldAlert className="w-10 h-10 text-red-600" />}
        </div>
        <h2 className="text-3xl font-bold text-slate-900 mb-3 tracking-tight">
          {isVictory ? 'Level Cleared!' : 'Game Over'}
        </h2>
        <p className="text-slate-500 text-sm mb-8">
          {isVictory ? `You mastered Level ${currentLevel?.id}!` : 'You ran out of lives. Keep practicing!'}
        </p>
        
        <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 mb-8 space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-slate-500 text-sm font-medium">Base Score</span>
            <span className="font-semibold text-slate-900">{score}</span>
          </div>
          {isVictory && (
            <div className="flex justify-between items-center">
              <span className="text-slate-500 text-sm font-medium">Lives Bonus ({lives}x50)</span>
              <span className="font-semibold text-emerald-600">+{lives * 50}</span>
            </div>
          )}
          <div className="pt-4 border-t border-slate-200/60 flex justify-between items-center">
            <span className="text-slate-900 font-semibold">Total Score</span>
            <span className="font-bold text-xl text-slate-900">{score + (isVictory ? lives * 50 : 0)}</span>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          {isVictory && currentLevel?.id !== 9 && (
            <button 
              onClick={() => startGame(LEVELS[currentLevel!.id])}
              className="w-full py-3.5 bg-slate-900 text-white rounded-full font-semibold text-sm hover:bg-slate-800 hover:-translate-y-0.5 shadow-md transition-all"
            >
              Next Level
            </button>
          )}
          <button 
            onClick={isVictory ? returnToMenu : () => startGame(currentLevel!)}
            className={`w-full py-3.5 rounded-full font-semibold text-sm transition-all ${
              isVictory 
                ? 'bg-white border border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900 shadow-sm' 
                : 'bg-slate-900 text-white hover:bg-slate-800 hover:-translate-y-0.5 shadow-md'
            }`}
          >
            {isVictory ? 'Return to Menu' : 'Try Again'}
          </button>
          {!isVictory && (
            <button 
              onClick={returnToMenu}
              className="w-full py-3.5 bg-white border border-slate-200 text-slate-600 rounded-full font-semibold text-sm hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900 shadow-sm transition-all"
            >
              Return to Menu
            </button>
          )}
        </div>
      </motion.div>
    );
  }

  if (gameState === 'playing' && challenges.length > 0) {
    const challenge = challenges[currentIndex];
    const sentenceParts = challenge.sentence.split('___');

    return (
      <div className="max-w-3xl mx-auto space-y-8">
        <header className="flex justify-between items-center bg-white p-4 rounded-2xl border border-slate-200/60 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="flex gap-1.5">
              {[1, 2, 3].map((heart) => (
                <Heart 
                  key={heart} 
                  className={`w-5 h-5 ${heart <= lives ? 'fill-red-500 text-red-500' : 'fill-slate-100 text-slate-200'}`} 
                />
              ))}
            </div>
            <div className="h-6 w-px bg-slate-200"></div>
            <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Level {currentLevel?.id}
            </div>
          </div>
          <div className="flex items-center gap-2 text-slate-900 font-bold text-lg">
            <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
            {score}
          </div>
        </header>

        <div className="w-full bg-slate-100 rounded-full h-1.5">
          <div 
            className="bg-slate-900 h-1.5 rounded-full transition-all duration-300"
            style={{ width: `${((currentIndex) / challenges.length) * 100}%` }}
          />
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-slate-200/60 text-center"
          >
            <h2 className="text-2xl md:text-3xl font-medium text-slate-900 mb-12 leading-relaxed tracking-tight">
              {sentenceParts[0]}
              <span className={`inline-block min-w-[120px] border-b-2 mx-2 px-4 pb-1 font-semibold ${
                !isAnswered 
                  ? 'border-slate-300 text-transparent' 
                  : selectedAnswer === challenge.correctAnswer 
                    ? 'border-emerald-500 text-emerald-600' 
                    : 'border-red-500 text-red-600'
              }`}>
                {isAnswered ? selectedAnswer : '???'}
              </span>
              {sentenceParts[1]}
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {challenge.options.map((option, idx) => {
                let btnClass = "p-5 rounded-2xl text-lg font-medium border transition-all ";
                
                if (!isAnswered) {
                  btnClass += "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50 text-slate-700 hover:text-slate-900 shadow-sm hover:shadow-md hover:-translate-y-0.5";
                } else {
                  if (option === challenge.correctAnswer) {
                    btnClass += "border-emerald-500 bg-emerald-50 text-emerald-700 shadow-sm";
                  } else if (option === selectedAnswer) {
                    btnClass += "border-red-500 bg-red-50 text-red-700 shadow-sm";
                  } else {
                    btnClass += "border-slate-100 bg-slate-50 text-slate-400 opacity-50";
                  }
                }

                return (
                  <motion.button
                    key={idx}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: idx * 0.1 }}
                    whileTap={!isAnswered ? { scale: 0.98 } : {}}
                    disabled={isAnswered}
                    onClick={() => handleAnswer(option)}
                    className={btnClass}
                  >
                    {option}
                  </motion.button>
                );
              })}
            </div>

            {isAnswered && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="mt-8 text-left"
              >
                <div className={`p-5 rounded-2xl text-sm ${selectedAnswer === challenge.correctAnswer ? 'bg-emerald-50 border border-emerald-100' : 'bg-red-50 border border-red-100'}`}>
                  <h4 className={`font-semibold mb-1.5 ${selectedAnswer === challenge.correctAnswer ? 'text-emerald-800' : 'text-red-800'}`}>
                    {selectedAnswer === challenge.correctAnswer ? 'Correct!' : 'Incorrect'}
                  </h4>
                  <p className={`leading-relaxed ${selectedAnswer === challenge.correctAnswer ? 'text-emerald-700' : 'text-red-700'}`}>
                    {challenge.explanation}
                  </p>
                </div>
                
                <button
                  onClick={handleNext}
                  className="mt-6 w-full py-3.5 bg-slate-900 text-white rounded-full font-semibold text-sm hover:bg-slate-800 hover:-translate-y-0.5 shadow-md transition-all flex items-center justify-center gap-2"
                >
                  {lives <= 0 ? 'See Results' : currentIndex < challenges.length - 1 ? 'Next Challenge' : 'Finish Level'}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-10">
      <header className="text-center max-w-2xl mx-auto mb-12">
        <div className="w-16 h-16 bg-slate-50 border border-slate-100 text-slate-900 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-sm">
          <Gamepad2 className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900 mb-3 tracking-tight">Grammar Quest</h1>
        <p className="text-sm text-slate-500">Embark on a journey to master English grammar. Complete levels to unlock harder challenges and earn points.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Basic Levels */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="space-y-4"
        >
          <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2 uppercase tracking-wider">
            <span className="w-6 h-6 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-600 flex items-center justify-center text-[10px] font-bold">1</span>
            Basic
          </h2>
          {LEVELS.filter(l => l.difficulty === 'Basic').map((level, idx) => (
            <LevelCard 
              key={level.id} 
              level={level} 
              isUnlocked={level.id <= unlockedLevel} 
              onPlay={() => startGame(level)} 
              delay={idx * 0.1}
            />
          ))}
        </motion.div>

        {/* Intermediate Levels */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="space-y-4"
        >
          <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2 uppercase tracking-wider">
            <span className="w-6 h-6 rounded-full bg-amber-50 border border-amber-100 text-amber-600 flex items-center justify-center text-[10px] font-bold">2</span>
            Intermediate
          </h2>
          {LEVELS.filter(l => l.difficulty === 'Intermediate').map((level, idx) => (
            <LevelCard 
              key={level.id} 
              level={level} 
              isUnlocked={level.id <= unlockedLevel} 
              onPlay={() => startGame(level)} 
              delay={idx * 0.1}
            />
          ))}
        </motion.div>

        {/* Advanced Levels */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="space-y-4"
        >
          <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2 uppercase tracking-wider">
            <span className="w-6 h-6 rounded-full bg-rose-50 border border-rose-100 text-rose-600 flex items-center justify-center text-[10px] font-bold">3</span>
            Advanced
          </h2>
          {LEVELS.filter(l => l.difficulty === 'Advanced').map((level, idx) => (
            <LevelCard 
              key={level.id} 
              level={level} 
              isUnlocked={level.id <= unlockedLevel} 
              onPlay={() => startGame(level)} 
              delay={idx * 0.1}
            />
          ))}
        </motion.div>
      </div>
    </div>
  );
}

function LevelCard({ level, isUnlocked, onPlay, delay = 0 }: { key?: React.Key, level: any, isUnlocked: boolean, onPlay: () => Promise<void> | void, delay?: number }) {
  return (
    <motion.button
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4, delay }}
      whileHover={isUnlocked ? { y: -4, boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)" } : {}}
      whileTap={isUnlocked ? { scale: 0.98 } : {}}
      onClick={onPlay}
      disabled={!isUnlocked}
      className={`w-full text-left p-5 rounded-2xl border transition-colors relative overflow-hidden ${
        isUnlocked 
          ? `bg-white border-slate-200/60 hover:border-slate-300 group cursor-pointer` 
          : `bg-slate-50/50 border-slate-100 opacity-75 cursor-not-allowed`
      }`}
    >
      <div className="flex justify-between items-start mb-3">
        <div className={`px-2.5 py-1 rounded-md text-[10px] uppercase tracking-wider font-semibold ${isUnlocked ? level.color : 'bg-slate-100 text-slate-400'}`}>
          Level {level.id}
        </div>
        {!isUnlocked && (
          <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center">
            <ShieldAlert className="w-3 h-3 text-slate-400" />
          </div>
        )}
        {isUnlocked && (
          <div className="w-6 h-6 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <Zap className="w-3 h-3 text-slate-900" />
          </div>
        )}
      </div>
      <h3 className={`text-sm font-semibold mb-1 tracking-tight ${isUnlocked ? 'text-slate-900 group-hover:text-slate-700 transition-colors' : 'text-slate-500'}`}>
        {level.title}
      </h3>
      <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">{level.topic}</p>
    </motion.button>
  );
}
