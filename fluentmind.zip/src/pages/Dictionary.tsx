import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, BookOpen, Volume2, Info, Loader2, AlertCircle } from 'lucide-react';
import { lookupWord, DictionaryEntry } from '../services/geminiService';

export default function Dictionary() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [entry, setEntry] = useState<DictionaryEntry | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsLoading(true);
    setError(null);
    try {
      const result = await lookupWord(searchQuery.trim());
      setEntry(result);
    } catch (err: any) {
      if (err?.message?.includes('429') || err?.message?.includes('RESOURCE_EXHAUSTED') || err?.message?.includes('quota')) {
        setError("The dictionary service is currently experiencing high traffic (rate limit exceeded). Please try again in a moment.");
      } else {
        setError("Could not find the word or an error occurred. Please try another word.");
      }
      setEntry(null);
    } finally {
      setIsLoading(false);
    }
  };

  const playPronunciation = () => {
    if ('speechSynthesis' in window && entry?.word) {
      const utterance = new SpeechSynthesisUtterance(entry.word);
      utterance.lang = 'en-GB'; // Oxford style usually defaults to British English, but can be en-US
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header className="text-center space-y-4 mb-12">
        <h1 className="text-4xl md:text-5xl font-normal text-slate-900 tracking-tight font-serif">Advanced Dictionary</h1>
        <p className="text-base text-slate-500 max-w-2xl mx-auto font-sans">
          Explore comprehensive meanings, origins, and advanced usage of any English word.
        </p>
      </header>

      <form onSubmit={handleSearch} className="relative max-w-2xl mx-auto">
        <div className="relative flex items-center shadow-sm rounded-full bg-white border border-slate-200/60 focus-within:border-slate-400 focus-within:ring-4 focus-within:ring-slate-100 transition-all">
          <Search className="absolute left-6 w-5 h-5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for a word (e.g., ephemeral, ubiquitous)..."
            className="w-full pl-14 pr-32 py-4 bg-transparent text-slate-900 placeholder:text-slate-400 text-base focus:outline-none"
          />
          <button
            type="submit"
            disabled={isLoading || !searchQuery.trim()}
            className="absolute right-2 px-6 py-2.5 bg-slate-900 text-white font-medium text-sm rounded-full hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Search'}
          </button>
        </div>
      </form>

      {error && (
        <motion.div 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          className="max-w-2xl mx-auto p-4 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-3 text-red-700"
        >
          <AlertCircle className="w-6 h-6 shrink-0" />
          <p>{error}</p>
        </motion.div>
      )}

      <AnimatePresence mode="wait">
        {entry && !isLoading && (
          <motion.div
            key={entry.word}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden"
          >
            {/* Word Header */}
            <div className="p-8 md:p-12 border-b border-slate-100 bg-white">
              <div className="flex flex-col md:flex-row md:items-baseline gap-4 md:gap-6 mb-6">
                <h2 className="text-5xl md:text-7xl font-normal text-slate-900 font-serif lowercase tracking-tight">
                  {entry.word}
                </h2>
                {entry.phonetic && (
                  <div className="flex items-center gap-3 text-lg text-slate-500 font-mono">
                    <span>{entry.phonetic}</span>
                    <button 
                      onClick={playPronunciation}
                      className="p-2 hover:bg-slate-100 text-slate-700 rounded-full transition-colors"
                      title="Listen to pronunciation"
                    >
                      <Volume2 className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>
              {entry.origin && (
                <div className="mt-8 pt-6 border-t border-slate-100">
                  <p className="text-slate-600 text-sm leading-relaxed max-w-3xl">
                    <span className="font-semibold text-slate-900 uppercase tracking-wider text-xs mr-2">Origin</span> 
                    <span className="font-serif italic text-base">{entry.origin}</span>
                  </p>
                </div>
              )}
            </div>

            {/* Meanings */}
            <div className="p-8 md:p-12 space-y-12 bg-slate-50/30">
              {entry.meanings.map((meaning, mIndex) => (
                <motion.div 
                  key={mIndex} 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: mIndex * 0.1 }}
                  className="space-y-8"
                >
                  <div className="flex items-center gap-4">
                    <h3 className="text-xl font-medium text-slate-900 italic font-serif">
                      {meaning.partOfSpeech}
                    </h3>
                    <div className="h-px bg-slate-200 flex-1"></div>
                  </div>

                  <ol className="space-y-10 list-decimal list-inside">
                    {meaning.definitions.map((def, dIndex) => (
                      <motion.li 
                        key={dIndex} 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: (mIndex * 0.1) + (dIndex * 0.05) }}
                        className="text-base text-slate-800 marker:text-slate-400 marker:font-mono pl-2"
                      >
                        <span className="pl-3 leading-relaxed">{def.definition}</span>
                        
                        {def.example && (
                          <div className="mt-3 pl-8 border-l border-slate-300 text-slate-600 font-serif italic text-lg">
                            "{def.example}"
                          </div>
                        )}

                        {(def.synonyms?.length || def.antonyms?.length) ? (
                          <div className="mt-5 pl-8 flex flex-wrap gap-x-8 gap-y-4 text-sm">
                            {def.synonyms && def.synonyms.length > 0 && (
                              <div className="flex items-start gap-3">
                                <span className="text-slate-400 font-semibold text-[10px] uppercase tracking-widest mt-1">Syn</span>
                                <div className="flex flex-wrap gap-2">
                                  {def.synonyms.map((syn, i) => (
                                    <span key={i} className="px-2.5 py-1 bg-white border border-slate-200 text-slate-600 rounded-md hover:border-slate-400 hover:text-slate-900 cursor-pointer transition-all shadow-sm" onClick={() => setSearchQuery(syn)}>
                                      {syn}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                            {def.antonyms && def.antonyms.length > 0 && (
                              <div className="flex items-start gap-3">
                                <span className="text-slate-400 font-semibold text-[10px] uppercase tracking-widest mt-1">Ant</span>
                                <div className="flex flex-wrap gap-2">
                                  {def.antonyms.map((ant, i) => (
                                    <span key={i} className="px-2.5 py-1 bg-white border border-slate-200 text-slate-600 rounded-md hover:border-slate-400 hover:text-slate-900 cursor-pointer transition-all shadow-sm" onClick={() => setSearchQuery(ant)}>
                                      {ant}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ) : null}
                      </motion.li>
                    ))}
                  </ol>
                </motion.div>
              ))}
            </div>

            {/* Usage Notes */}
            {entry.usageNotes && (
              <div className="p-8 md:p-12 bg-slate-900 text-slate-50 border-t border-slate-800">
                <div className="flex items-start gap-5">
                  <div className="p-2.5 bg-slate-800 text-slate-300 rounded-xl shrink-0">
                    <Info className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-300 uppercase tracking-widest mb-3">Usage Notes</h4>
                    <p className="text-slate-300 leading-relaxed font-serif text-lg">
                      {entry.usageNotes}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
