import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { collection, query, orderBy, limit, onSnapshot, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { format } from 'date-fns';
import { Trophy, Flame, Target, Activity } from 'lucide-react';

export default function Dashboard() {
  const { user } = useAuth();
  const [sessions, setSessions] = useState<any[]>([]);
  const [userProfile, setUserProfile] = useState<any>(null);

  useEffect(() => {
    if (!user) return;

    const userRef = doc(db, 'users', user.uid);
    const unsubscribeUser = onSnapshot(userRef, (doc) => {
      if (doc.exists()) {
        setUserProfile(doc.data());
      }
    });

    const sessionsRef = collection(db, 'users', user.uid, 'sessions');
    const q = query(sessionsRef, orderBy('createdAt', 'asc'), limit(30));
    
    const unsubscribeSessions = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        date: doc.data().createdAt?.toDate() ? format(doc.data().createdAt.toDate(), 'MMM dd') : ''
      }));
      setSessions(data);
    });

    return () => {
      unsubscribeUser();
      unsubscribeSessions();
    };
  }, [user]);

  const recentSessions = [...sessions].reverse().slice(0, 5);
  const avgFluency = sessions.length > 0 
    ? Math.round(sessions.reduce((acc, s) => acc + s.fluencyScore, 0) / sessions.length) 
    : 0;

  return (
    <div className="space-y-8">
      <header className="mb-10">
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Welcome back, {user?.displayName?.split(' ')[0]}!</h1>
        <p className="text-slate-500 mt-2 text-sm">Here's your communication progress and recent activity.</p>
      </header>

      {/* Stats Grid */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ staggerChildren: 0.1 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {[
          { label: 'Average Fluency', value: `${avgFluency}%`, icon: Activity, color: 'text-blue-600', bg: 'bg-blue-50/50', border: 'border-blue-100' },
          { label: 'Total Sessions', value: sessions.length, icon: Target, color: 'text-slate-900', bg: 'bg-slate-50/50', border: 'border-slate-200/60' },
          { label: 'Current Streak', value: `${userProfile?.streak || 0} Days`, icon: Flame, color: 'text-orange-600', bg: 'bg-orange-50/50', border: 'border-orange-100' },
          { label: 'Current Level', value: `Lvl ${userProfile?.level || 1}`, icon: Trophy, color: 'text-emerald-600', bg: 'bg-emerald-50/50', border: 'border-emerald-100' },
        ].map((stat, idx) => (
          <motion.div 
            key={idx} 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: idx * 0.1 }}
            whileHover={{ y: -4, boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)" }}
            className={`bg-white p-5 rounded-2xl border ${stat.border} shadow-sm flex items-center gap-4 transition-colors`}
          >
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${stat.bg} ${stat.color}`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">{stat.label}</p>
              <p className="text-2xl font-bold text-slate-900 tracking-tight">{stat.value}</p>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Charts */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8"
      >
        <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-base font-semibold text-slate-900">Fluency Trend</h2>
            <span className="text-xs font-medium bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full">Last 30 Sessions</span>
          </div>
          <div className="h-64">
            {sessions.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={sessions} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorFluency" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0f172a" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#0f172a" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 11 }} dy={10} />
                  <YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 11 }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    itemStyle={{ color: '#0f172a', fontWeight: 600 }}
                  />
                  <Area type="monotone" dataKey="fluencyScore" stroke="#0f172a" strokeWidth={2} fillOpacity={1} fill="url(#colorFluency)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 text-sm">No data yet. Start practicing!</div>
            )}
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-base font-semibold text-slate-900">Skill Breakdown</h2>
          </div>
          <div className="h-64">
            {sessions.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sessions} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 11 }} dy={10} />
                  <YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 11 }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    itemStyle={{ fontWeight: 600 }}
                  />
                  <Line type="monotone" dataKey="grammarScore" name="Grammar" stroke="#10b981" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="vocabularyScore" name="Vocabulary" stroke="#f59e0b" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="clarityScore" name="Clarity" stroke="#3b82f6" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 text-sm">No data yet. Start practicing!</div>
            )}
          </div>
        </div>
      </motion.div>

      {/* Recent Activity */}
      <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden mt-8">
        <div className="p-6 border-b border-slate-100">
          <h2 className="text-base font-semibold text-slate-900">Recent Practice Sessions</h2>
        </div>
        <div className="divide-y divide-slate-100">
          {recentSessions.length > 0 ? recentSessions.map((session) => (
            <div key={session.id} className="p-4 sm:p-6 hover:bg-slate-50/50 transition-colors flex items-center justify-between group">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 group-hover:bg-white group-hover:shadow-sm transition-all">
                  {session.type === 'text' ? <Activity className="w-4 h-4" /> : <Activity className="w-4 h-4" />}
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-900 capitalize">{session.type} Practice</p>
                  <p className="text-xs text-slate-500 mt-0.5">{session.date}</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-0.5">Fluency</p>
                  <p className="text-lg font-bold text-slate-900">{session.fluencyScore}%</p>
                </div>
              </div>
            </div>
          )) : (
            <div className="p-8 text-center text-slate-400 text-sm">No recent sessions found.</div>
          )}
        </div>
      </div>
    </div>
  );
}
